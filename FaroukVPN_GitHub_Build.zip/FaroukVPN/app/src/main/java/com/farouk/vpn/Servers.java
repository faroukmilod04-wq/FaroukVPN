package com.farouk.vpn;

import java.util.Arrays;
import java.util.List;

public final class Servers {
    private Servers() {}

    // TODO: ضع عنوان ومفتاح كل سيرفر حقيقي لديك
    private static final String EP = "YOUR_SERVER_IP:51820";
    private static final String PK = "YOUR_SERVER_PUBLIC_KEY";

    public static final List<Server> LIST = Arrays.asList(
        new Server("United Kingdom", "London",    "🇬🇧", EP, PK),
        new Server("Singapore",      "Singapore", "🇸🇬", EP, PK),
        new Server("United States",  "Miami",     "🇺🇸", EP, PK),
        new Server("France",         "Paris",     "🇫🇷", EP, PK),
        new Server("Switzerland",    "Berne",     "🇨🇭", EP, PK),
        new Server("Italy",          "Naples",    "🇮🇹", EP, PK),
        new Server("Germany",        "Berlin",    "🇩🇪", EP, PK),
        new Server("Hong Kong",      "Hong Kong", "🇭🇰", EP, PK)
    );
}
