package com.farouk.vpn;

import android.content.Intent;
import android.graphics.Color;
import android.net.TrafficStats;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import java.util.Locale;

public class MainActivity extends ComponentActivity implements VpnController.Listener {

    private static final int GREEN = Color.parseColor("#3DDC84");
    private static final int ORANGE = Color.parseColor("#FFB020");

    private VpnController vpn;

    private View homeView, serversView, capsule, powerButton;
    private TextView statusDot, statusText, timerText, downText, upText;
    private TextView locationFlag, locationName, powerLabel;
    private LinearLayout serverList;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean busy = false;
    private String busyMsg = "";
    private int selected = -1; // -1 = Smart Location
    private long lastTick = 0, lastRx = 0, lastTx = 0;

    private final ActivityResultLauncher<Intent> vpnPermission =
        registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    connect();
                } else {
                    toast("VPN permission denied");
                }
            });

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateStats();
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vpn = VpnController.get(this);

        homeView = findViewById(R.id.home_view);
        serversView = findViewById(R.id.servers_view);
        capsule = findViewById(R.id.capsule);
        powerButton = findViewById(R.id.power_button);
        statusDot = findViewById(R.id.status_dot);
        statusText = findViewById(R.id.status_text);
        timerText = findViewById(R.id.timer_text);
        downText = findViewById(R.id.down_text);
        upText = findViewById(R.id.up_text);
        locationFlag = findViewById(R.id.location_flag);
        locationName = findViewById(R.id.location_name);
        powerLabel = findViewById(R.id.power_label);
        serverList = findViewById(R.id.server_list);

        buildServerList();

        powerButton.setOnClickListener(v -> onPowerClicked());
        findViewById(R.id.location_pill).setOnClickListener(v -> showScreen(true));
        findViewById(R.id.back_button).setOnClickListener(v -> showScreen(false));
        findViewById(R.id.nav_home).setOnClickListener(v -> showScreen(false));
        findViewById(R.id.nav_location).setOnClickListener(v -> showScreen(true));
        findViewById(R.id.nav_speed).setOnClickListener(v -> toast("Speed Test: coming soon"));
        findViewById(R.id.nav_settings).setOnClickListener(v -> toast("Settings: coming soon"));
        findViewById(R.id.tab_premium).setOnClickListener(v -> toast("Premium servers: coming soon"));
        findViewById(R.id.upgrade_button).setOnClickListener(v -> toast("Premium: coming soon"));

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (serversView.getVisibility() == View.VISIBLE) {
                    showScreen(false);
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        showScreen(false);
        render();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (vpn.serverIndex >= 0) selected = vpn.serverIndex;
        render();
        ui.post(ticker);
    }

    @Override
    protected void onStop() {
        super.onStop();
        ui.removeCallbacks(ticker);
    }

    // ---------- الاتصال ----------

    private void onPowerClicked() {
        if (busy) return;
        if (vpn.isUp()) {
            busy = true;
            busyMsg = "Disconnecting…";
            render();
            vpn.disconnect(this);
        } else {
            requestConnect();
        }
    }

    private void requestConnect() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            vpnPermission.launch(intent);
        } else {
            connect();
        }
    }

    private void connect() {
        busy = true;
        busyMsg = "Connecting…";
        render();
        vpn.connect(selected < 0 ? 0 : selected, this);
    }

    @Override
    public void onStateChanged(boolean up) {
        busy = false;
        lastTick = 0;
        render();
    }

    @Override
    public void onError(String message) {
        busy = false;
        render();
        toast("Error: " + message);
    }

    // ---------- الواجهة ----------

    private void buildServerList() {
        LayoutInflater inflater = LayoutInflater.from(this);
        for (int i = 0; i < Servers.LIST.size(); i++) {
            final int idx = i;
            Server s = Servers.LIST.get(i);
            View row = inflater.inflate(R.layout.item_server, serverList, false);
            ((TextView) row.findViewById(R.id.flag)).setText(s.flag);
            ((TextView) row.findViewById(R.id.name)).setText(s.name);
            ((TextView) row.findViewById(R.id.city)).setText(s.city);
            row.findViewById(R.id.connect_btn).setOnClickListener(v -> onServerPicked(idx));
            serverList.addView(row);
        }
    }

    private void onServerPicked(int idx) {
        if (busy) return;
        selected = idx;
        showScreen(false);
        if (vpn.isUp() && vpn.serverIndex == idx) {
            render();
            return;
        }
        requestConnect();
    }

    private void showScreen(boolean servers) {
        homeView.setVisibility(servers ? View.GONE : View.VISIBLE);
        serversView.setVisibility(servers ? View.VISIBLE : View.GONE);
        findViewById(R.id.nav_home).setBackgroundResource(servers ? 0 : R.drawable.bg_nav_selected);
        findViewById(R.id.nav_location).setBackgroundResource(servers ? R.drawable.bg_nav_selected : 0);
    }

    private void render() {
        boolean up = vpn.isUp();

        if (busy) {
            statusDot.setTextColor(ORANGE);
            statusText.setText(busyMsg);
        } else if (up) {
            statusDot.setTextColor(GREEN);
            statusText.setText("Connected");
        } else {
            statusDot.setTextColor(ORANGE);
            statusText.setText("Disconnected");
        }

        powerLabel.setText(up ? "STOP" : "START");
        capsule.setBackgroundResource(up ? R.drawable.bg_capsule_on : R.drawable.bg_capsule);

        int shown = up && vpn.serverIndex >= 0 ? vpn.serverIndex : selected;
        if (shown >= 0) {
            Server s = Servers.LIST.get(shown);
            locationFlag.setText(s.flag);
            locationName.setText(s.name);
        } else {
            locationFlag.setText("🌐");
            locationName.setText("Smart Location");
        }

        for (int i = 0; i < serverList.getChildCount(); i++) {
            TextView btn = serverList.getChildAt(i).findViewById(R.id.connect_btn);
            boolean current = up && vpn.serverIndex == i;
            btn.setText(current ? "Connected" : "Connect");
            btn.setBackgroundResource(current ? R.drawable.bg_btn_connected : R.drawable.bg_btn_connect);
        }

        updateStats();
    }

    private void updateStats() {
        if (!vpn.isUp()) {
            timerText.setText("00:00:00");
            downText.setText("↓ 0.0 Mbps");
            upText.setText("↑ 0.0 Mbps");
            lastTick = 0;
            return;
        }

        long now = SystemClock.elapsedRealtime();
        long sec = Math.max(0, (now - vpn.connectedSince) / 1000);
        timerText.setText(String.format(Locale.US, "%02d:%02d:%02d",
            sec / 3600, (sec % 3600) / 60, sec % 60));

        long rx = TrafficStats.getTotalRxBytes();
        long tx = TrafficStats.getTotalTxBytes();
        if (lastTick > 0 && rx >= 0 && tx >= 0 && now > lastTick) {
            double dt = (now - lastTick) / 1000.0;
            downText.setText(String.format(Locale.US, "↓ %.1f Mbps", (rx - lastRx) * 8 / 1e6 / dt));
            upText.setText(String.format(Locale.US, "↑ %.1f Mbps", (tx - lastTx) * 8 / 1e6 / dt));
        }
        lastTick = now;
        lastRx = rx;
        lastTx = tx;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
