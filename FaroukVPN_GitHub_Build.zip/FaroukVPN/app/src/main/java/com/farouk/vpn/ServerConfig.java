package com.farouk.vpn;

import com.wireguard.config.BadConfigException;
import com.wireguard.config.Config;
import com.wireguard.config.Interface;
import com.wireguard.config.Peer;

final class ServerConfig {
    private ServerConfig() {}

    // TODO: مفتاح العميل الخاص وعنوانه. لا ترفعه إلى Git،
    // والأفضل لاحقاً توليده على الجهاز وتخزينه في Android Keystore.
    private static final String CLIENT_PRIVATE_KEY = "YOUR_CLIENT_PRIVATE_KEY";
    private static final String CLIENT_ADDRESS = "10.0.0.2/32";
    private static final String DNS = "1.1.1.1";

    static Config build(Server s) throws BadConfigException {
        Interface itf = new Interface.Builder()
            .parsePrivateKey(CLIENT_PRIVATE_KEY)
            .parseAddresses(CLIENT_ADDRESS)
            .parseDnsServers(DNS)
            .build();

        Peer peer = new Peer.Builder()
            .parsePublicKey(s.publicKey)
            .parseEndpoint(s.endpoint)
            .parseAllowedIPs("0.0.0.0/0, ::/0")
            .parsePersistentKeepalive("25")
            .build();

        return new Config.Builder().setInterface(itf).addPeer(peer).build();
    }
}
