package com.farouk.vpn;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** يدير نفق WireGuard خارج الـ UI thread، ويحتفظ بالحالة عند تدوير الشاشة. */
public final class VpnController {

    public interface Listener {
        void onStateChanged(boolean up);
        void onError(String message);
    }

    private static VpnController instance;

    public static synchronized VpnController get(Context context) {
        if (instance == null) instance = new VpnController(context.getApplicationContext());
        return instance;
    }

    private final GoBackend backend;
    private final FaroukTunnel tunnel = new FaroukTunnel();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public volatile int serverIndex = -1;
    public volatile long connectedSince = 0;

    private VpnController(Context appContext) {
        backend = new GoBackend(appContext);
    }

    public boolean isUp() {
        return backend.getState(tunnel) == Tunnel.State.UP;
    }

    public void connect(int index, Listener l) {
        final Server server = Servers.LIST.get(index);
        io.execute(() -> {
            try {
                Config cfg = ServerConfig.build(server);
                if (backend.getState(tunnel) == Tunnel.State.UP) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null);
                }
                backend.setState(tunnel, Tunnel.State.UP, cfg);
                serverIndex = index;
                connectedSince = SystemClock.elapsedRealtime();
                main.post(() -> l.onStateChanged(true));
            } catch (Exception e) {
                String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                main.post(() -> l.onError(msg));
            }
        });
    }

    public void disconnect(Listener l) {
        io.execute(() -> {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null);
                serverIndex = -1;
                connectedSince = 0;
                main.post(() -> l.onStateChanged(false));
            } catch (Exception e) {
                String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                main.post(() -> l.onError(msg));
            }
        });
    }
}
