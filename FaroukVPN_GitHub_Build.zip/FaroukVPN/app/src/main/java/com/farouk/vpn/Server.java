package com.farouk.vpn;

public final class Server {
    public final String name;
    public final String city;
    public final String flag;
    public final String endpoint;   // host:port لسيرفر WireGuard
    public final String publicKey;  // المفتاح العام للسيرفر

    public Server(String name, String city, String flag, String endpoint, String publicKey) {
        this.name = name;
        this.city = city;
        this.flag = flag;
        this.endpoint = endpoint;
        this.publicKey = publicKey;
    }
}
