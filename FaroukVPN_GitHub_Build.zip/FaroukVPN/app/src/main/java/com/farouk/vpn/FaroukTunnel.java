package com.farouk.vpn;

import com.wireguard.android.backend.Tunnel;

final class FaroukTunnel implements Tunnel {
    @Override
    public String getName() {
        return "farouk";
    }

    @Override
    public void onStateChange(State newState) {
        // الحالة تُدار عبر VpnController
    }
}
